/*=========================================================
DRIVE AWAKE
APPLE STYLE INTERACTIONS
=========================================================*/


/*=========================
CUSTOM CURSOR
=========================*/

const cursor = document.querySelector(".cursor");

window.addEventListener("mousemove",(e)=>{

cursor.style.left=e.clientX+"px";

cursor.style.top=e.clientY+"px";

});


/*=========================
SCROLL REVEAL
=========================*/

const observer = new IntersectionObserver(entries=>{

entries.forEach(entry=>{

if(entry.isIntersecting){

entry.target.classList.add("show");

}

});

},{
threshold:.18
});

document.querySelectorAll(".section,.technology,.sensorSection,.camera,.mobile,.cta").forEach(sec=>{

observer.observe(sec);

});


/*=========================
3D CARDS
=========================*/

const cards=document.querySelectorAll(".card,.sensor,.glass");

cards.forEach(card=>{

card.addEventListener("mousemove",(e)=>{

const rect=card.getBoundingClientRect();

const x=e.clientX-rect.left;

const y=e.clientY-rect.top;

const rotateY=((x/rect.width)-0.5)*18;

const rotateX=((y/rect.height)-0.5)*-18;

card.style.transform=

`perspective(900px)

rotateX(${rotateX}deg)

rotateY(${rotateY}deg)

translateY(-10px)`;

});

card.addEventListener("mouseleave",()=>{

card.style.transform=

"perspective(900px) rotateX(0) rotateY(0)";

});

});


/*=========================
SCROLL BAR
=========================*/

window.addEventListener("scroll",()=>{

const scroll=

window.scrollY;

const height=

document.body.scrollHeight-window.innerHeight;

const value=

(scroll/height)*100;

document.body.style.setProperty("--scroll",value+"%");

});


/*=========================
BUTTON RIPPLE
=========================*/

document.querySelectorAll("button").forEach(button=>{

button.addEventListener("click",function(e){

let circle=document.createElement("span");

circle.classList.add("ripple");

this.appendChild(circle);

let x=e.clientX-this.offsetLeft;

let y=e.clientY-this.offsetTop;

circle.style.left=x+"px";

circle.style.top=y+"px";

setTimeout(()=>{

circle.remove();

},700);

});

});


/*=========================
FLOAT EFFECT
=========================*/

const hero=document.querySelector(".heroImage");

window.addEventListener("mousemove",(e)=>{

const x=(window.innerWidth/2-e.clientX)/40;

const y=(window.innerHeight/2-e.clientY)/40;

hero.style.transform=

`translate(${x}px,${y}px)`;

});


/*=========================
COUNT UP
=========================*/

const numbers=document.querySelectorAll(".glass h3");

let started=false;

window.addEventListener("scroll",()=>{

const trigger=document.querySelector(".technology");

if(window.scrollY>

trigger.offsetTop-500

&& !started){

started=true;

animateNumber(numbers[0],120,"+");

animateNumber(numbers[1],97,"%");

animateNumber(numbers[2],0.8,"s");

}

});

function animateNumber(el,end,symbol){

let start=0;

let increment=end/80;

let interval=setInterval(()=>{

start+=increment;

if(start>=end){

start=end;

clearInterval(interval);

}

if(symbol=="s"){

el.innerHTML=start.toFixed(1)+symbol;

}else{

el.innerHTML=Math.floor(start)+symbol;

}

},20);

}


/*=========================
NAVIGATION BLUR
=========================*/

const nav=document.querySelector("nav");

window.addEventListener("scroll",()=>{

if(window.scrollY>100){

nav.style.background="rgba(12,12,12,.82)";

nav.style.border="1px solid rgba(126,161,107,.25)";

}

else{

nav.style.background="rgba(20,20,20,.45)";

nav.style.border="1px solid rgba(255,255,255,.08)";

}

});


/*=========================
PARALLAX
=========================*/

const rings=document.querySelectorAll(".ring1,.ring2,.ring3");

window.addEventListener("mousemove",(e)=>{

const x=e.clientX/window.innerWidth;

const y=e.clientY/window.innerHeight;

rings.forEach((ring,index)=>{

const speed=(index+1)*12;

ring.style.transform=

`translate(${x*speed}px,${y*speed}px)`;

});

});


/*=========================
IMAGE ZOOM
=========================*/

document.querySelectorAll("img").forEach(img=>{

img.addEventListener("mouseenter",()=>{

img.style.filter="brightness(110%)";

});

img.addEventListener("mouseleave",()=>{

img.style.filter="brightness(100%)";

});

});


console.log("Drive Awake Loaded");
/*=========================
LIVE BIOMETRICS
=========================*/

const heart=document.getElementById("heartRate");

const respiration=document.getElementById("respiration");

const temperature=document.getElementById("temperature");

const stress=document.getElementById("stress");

const risk=document.getElementById("risk");

const progress=document.getElementById("progress");

setInterval(()=>{

let hr=Math.floor(Math.random()*18)+65;

let rr=Math.floor(Math.random()*6)+14;

let temp=(36+Math.random()).toFixed(1);

let fatigue=Math.floor(Math.random()*100);

heart.innerHTML=hr+" BPM";

respiration.innerHTML=rr+" RPM";

temperature.innerHTML=temp+" °C";

progress.style.width=fatigue+"%";

if(fatigue<35){

risk.innerHTML="LOW";

risk.style.color="#7CFF8B";

stress.innerHTML="Normal";

}

else if(fatigue<70){

risk.innerHTML="MEDIUM";

risk.style.color="#ffd54a";

stress.innerHTML="Elevated";

}

else{

risk.innerHTML="HIGH";

risk.style.color="#ff5c5c";

stress.innerHTML="Critical";

}

},2500);

