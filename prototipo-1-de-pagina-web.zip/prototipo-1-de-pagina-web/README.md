# prototipo 1 de pagina web

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/manuela-granados-the-solid/pen/019fb15c-ea70-7588-8528-6dd90a377dca](https://codepen.io/editor/manuela-granados-the-solid/pen/019fb15c-ea70-7588-8528-6dd90a377dca).

